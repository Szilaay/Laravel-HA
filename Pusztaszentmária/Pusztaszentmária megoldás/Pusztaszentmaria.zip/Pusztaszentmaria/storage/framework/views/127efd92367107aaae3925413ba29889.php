<footer class="container-fuid bg-dark mt-5">
    <div class="container pt-3 text-white">
                <h5>Elérhetőségek</h5>
                <hr>
        <div class="row">
            <div class="col-sm">
                <p>
                    Polgármesteri Hivatal<br>
                    6666 Pusztaszentmária, Petőfi út 1
                </p>
            </div>
            <div class="col-sm">
                <p>
                    Telefon: <a class="link-light" href="tel:0666123456">06/66 123-456</a><br>
                    E-mail:  <a class="link-light" href="mailto:hivatal@pusztaszentmaria.hu">hivatal@pusztaszentmaria.hu</a>
                </p>

            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/layouts/footer.blade.php ENDPATH**/ ?>