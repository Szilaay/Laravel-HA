

<?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <h1 class="pt-3 text-center">Regisztráció</h1>
    
    <form action="/register" method="post">
        <?php echo csrf_field(); ?>
        <div class="py-2">
            <label for="nev" class="form-label">Felhasználónév: </label>
            <input type="text" name="nev" id="nev" class="form-control" value="<?php echo e(old('nev')); ?>">
            <?php $__errorArgs = ['nev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-2">
            <label for="email" class="form-label">E-mail: </label>
            <input type="text" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-2">
            <label for="password" class="form-label">Jelszó:</label>
            <input type="password" name="password" id="password" class="form-control">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-2">
            <label for="password_confirmation" class="form-label">Jelszó megerősítése:</label>
            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-2">
            <button type="submit" class="btn btn-primary w-100">Regisztráció</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/User_Interface/register.blade.php ENDPATH**/ ?>