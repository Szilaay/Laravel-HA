<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
    <div class="pt-3">
        <div class="text-center alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    </div>
    <?php elseif(session('error')): ?>
    <div class="pt-3">
        <div class="text-center alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <?php endif; ?>
    <div class="col-md-9">
        <h1 class="py-3 text-center">Polgármesteri köszöntő</h1>
        <p class="text-center">
            <b>Pusztaszentmária Község Önkormányzata nevében sok szeretettel köszöntöm honlapunk látogatóit!</b>
        </p>
        <p>
            Örülök, hogy időt szentel arra, hogy településünkkel részletesebben megismerkedjen. Ha szörfözik a világhálón, akkor láthatja, hogy községünkből csak egy van. Mi itt élők ezt tudjuk, nap mint nap tapasztaljuk. A település múltja nagyon gazdag és sokszínű. 
        </p>
        <p>
            Kérem kísérje figyelemmel honlapunkat, ahol igyekszünk bemutatni településünk múltját, jelenét, és jövőjét. A virtuálison túl személyes látogatásra is szívesen látjuk az ide utazókat, hisz meggyőzősésem, hogy a község és környékének szépsége, az itt lakók vendégszeretete elsősorban itt, helyben érzékelhető.
        </p>
        <p>
            Kiss Béla Lajos<br>
            polgármester
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/welcome.blade.php ENDPATH**/ ?>