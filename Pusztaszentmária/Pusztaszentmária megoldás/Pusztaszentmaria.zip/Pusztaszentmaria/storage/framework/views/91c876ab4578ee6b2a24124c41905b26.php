

<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <h1 class="pt-3 text-center">Hírek</h1>

        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container pt-3">
            <h2> <?php echo e($item-> title); ?> </h2>
            <div class="row">
                <div class="col-md-8">
                    <p> <?php echo e(date('Y. m. d.', strtotime($item->date))); ?> </p>
                    <p> <?php echo $item -> text; ?> </p>
                </div>
                <div class="col-md-4">
                    <img src="img/<?php echo e($item -> img); ?>" alt="<?php echo e($item -> img); ?>" class="img-fluid">
                </div>
            </div>
        </div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/news.blade.php ENDPATH**/ ?>