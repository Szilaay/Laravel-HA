<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php $__env->startSection('title'); ?><?php $__env->stopSection(); ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/mystyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Asap&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans+Narrow&display=swap" rel="stylesheet">
    <script src="assets/js/bootstrap.bundle.js"></script>
</head>
<body class="bg-light">
    <?php $__env->startSection('content'); ?>
        
    <?php $__env->stopSection(); ?>
</body>
</html><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/layouts/main.blade.php ENDPATH**/ ?>