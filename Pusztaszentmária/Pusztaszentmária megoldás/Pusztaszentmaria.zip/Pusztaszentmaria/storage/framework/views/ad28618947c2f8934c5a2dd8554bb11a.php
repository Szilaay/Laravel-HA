

<?php $__env->startSection('content'); ?>
    <div class="col-md-9">

        <?php if(session('success')): ?>
            <div class="pt-3">
                <div class="text-center alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            </div>
        <?php endif; ?>
        <h1 class="pt-3 text-center">Vendégkönyv</h1>

        <?php if(auth()->guard()->guest()): ?>
            <h3 class="text-center text-danger">A vendégkönyvbe való bejegyzéshez be kell jelentkezned!</h3>
        <?php else: ?>
            <form action="/guestbook" method="post">
                <?php echo csrf_field(); ?>
                <div class="py-2">
                    <label for="nev" class="form-label">Név: <span class="red"><b>*</b></span></label>
                    <input type="text" name="nev" id="nev" class="form-control" value="<?php echo e(Auth::user() -> nev); ?>" readonly>
                    <?php $__errorArgs = ['nev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="py-2">
                    <label for="email" class="form-label">E-mail: <span class="red"><b>*</b></span></label>
                    <input type="text" name="email" id="email" class="form-control" value="<?php echo e(Auth::user() -> email); ?>" readonly>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="py-2">
                    <label for="message" class="form-label">Üzenet: <span class="red"><b>*</b></span></label>
                    <textarea name="message" id="message" class="form-control" cols="30" rows="10" style="max-height: 150px; min-height: 150px"></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <span class="red"><b>* kötelező mező</b></span>
                <div class="py-2">
                    <button type="submit" class="btn btn-outline-primary">Beküld</button>
                </div>
            </form>
        <?php endif; ?>

        <hr>

        <?php $__currentLoopData = $guestbook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h5><?php echo e($item -> nev); ?> - <a href="mailto:<?php echo e($item -> email); ?>"> <?php echo e($item -> email); ?> </a></h5>
            <p> <?php echo e(date('Y. m. d.', strtotime($item -> date))); ?> </p>
            <p> <?php echo e($item -> message); ?> </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/guestbook.blade.php ENDPATH**/ ?>