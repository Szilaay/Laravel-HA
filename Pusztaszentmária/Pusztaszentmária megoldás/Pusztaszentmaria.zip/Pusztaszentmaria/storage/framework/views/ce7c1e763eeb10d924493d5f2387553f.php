

<?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <?php if(session('success')): ?>
    <div class="pt-3">
        <div class="text-center alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    </div>
    <?php elseif(session('error')): ?>
        <div class="pt-3">
            <div class="text-center alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        </div>
    <?php endif; ?>
    <h1 class="pt-3 text-center">Üdv <?php echo e(Auth::user() -> nev); ?>! </h1>

    <div class="py-3">
        <h2 class="text-center">Profil</h2>
        <p class="text-center">E-mail cím: <?php echo e(Auth::user() -> email); ?></p>

        <div class="text-center">
            <a href="/logout" class="btn btn-danger">Kijelentkezés</a>
        </div>

        <h2 class="pt-3 text-center">Jelszóváltoztatás</h2>
        <form action="/profil" method="post">
            <?php echo csrf_field(); ?>
            <div class="py-2">
                <label for="old_password" class="form-label">Régi jelszó:</label>
                <input type="password" name="old_password" id="old_password" class="form-control">
                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="py-2">
                <label for="password" class="form-label">Új jelszó :</label>
                <input type="password" name="password" id="password" class="form-control">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="py-2">
                <label for="password_confirmation" class="form-label">Új jelszó megerősítése:</label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
            </div>
            <div class="py-2">
                <button type="submit" class="btn btn-primary w-100">Jelszóváltoztatás</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\szucs.szilard\Desktop\Laravel-HA\Pusztaszentmária\Pusztaszentmária megoldás\Pusztaszentmaria\resources\views/User_Interface/profil.blade.php ENDPATH**/ ?>